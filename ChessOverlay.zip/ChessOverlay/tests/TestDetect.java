import com.chesshint.overlay.core.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

public class TestDetect {
    static byte code(char c) {
        if (c == '.') return 0;
        int t = "pnbrqk".indexOf(Character.toLowerCase(c)) + 1;
        return (byte) (Character.isUpperCase(c) ? t : t | 8);
    }
    public static void main(String[] args) throws Exception {
        int totalFail = 0;
        for (String dir : args) {
            List<String> lines = Files.readAllLines(Paths.get(dir, "expected.txt"));
            String[] h = lines.get(0).split(" ");
            float tx = Float.parseFloat(h[0]), ty = Float.parseFloat(h[1]), tc = Float.parseFloat(h[2]);
            Tracker tr = new Tracker();
            Detector.PieceSet set = new Detector.PieceSet();
            Detector.Geo geo = null;
            int bad = 0, n = 0;
            long tFind = 0, tScan = 0;
            StringBuilder log = new StringBuilder();
            for (int k = 1; k < lines.size(); k++) {
                String[] p = lines.get(k).split(" ");
                if (p.length < 2) continue;
                BufferedImage im = ImageIO.read(new File(p[0]));
                int w = im.getWidth(), hh = im.getHeight();
                int[] px = im.getRGB(0, 0, w, hh, null, 0, w);
                if (geo == null) {
                    long t0 = System.nanoTime();
                    geo = Detector.find(px, w, hh);
                    tFind = (System.nanoTime() - t0) / 1000000;
                    if (geo == null) { log.append("  доска НЕ найдена\n"); bad++; break; }
                    float err = Math.max(Math.max(Math.abs(geo.x - tx), Math.abs(geo.y - ty)), Math.abs(geo.cell - tc) * 8);
                    log.append(String.format("  геометрия: x=%.1f y=%.1f cell=%.2f (истина %.0f %.0f %.2f) ошибка=%.1fpx, поиск %dмс%n", geo.x, geo.y, geo.cell, tx, ty, tc, err, tFind));
                    if (err > 4) { log.append("  ГЕОМЕТРИЯ ТОЧНОСТЬ ПЛОХАЯ\n"); bad++; }
                }
                long t0 = System.nanoTime();
                Detector.Scan s = Detector.scan(px, w, hh, geo, set, tr.whiteBottom);
                tScan = Math.max(tScan, (System.nanoTime() - t0) / 1000000);
                n++;
                byte[] truth = new byte[64];
                for (int i = 0; i < 64; i++) truth[i] = code(p[1].charAt(i));
                if (s.learned) tr.whiteBottom = s.whiteBottom;
                if (s.board == null) { log.append("  кадр " + (k - 1) + ": не распознан (" + s.problem + ") maxD=" + Detector.dbgWorstD + " margin=" + Detector.dbgMinMargin + "\n"); bad++; continue; }
                boolean exact = Arrays.equals(s.board, truth);
                Tracker.Status st = tr.update(s.board);
                boolean tracked = tr.cur != null && tr.cur.samePlacement(truth);
                if (!exact || !tracked) { log.append("  кадр " + (k - 1) + ": расстановка " + (exact ? "верна" : "ОШИБКА") + ", трекер " + st + (tracked ? "" : " ОШИБКА") + "\n"); bad++; }
            }
            System.out.printf("%-26s кадров=%d ошибок=%d  whiteBottom=%b  maxD=%.3f minMargin=%.3f  скан<=%dмс%n", dir, n, bad, tr.whiteBottom, Detector.dbgWorstD, Detector.dbgMinMargin, tScan);
            System.out.print(log);
            totalFail += bad;
        }
        System.out.println(totalFail == 0 ? "ВСЕ СЦЕНАРИИ ПРОЙДЕНЫ" : "ВСЕГО ОШИБОК: " + totalFail);
    }
}
