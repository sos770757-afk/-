import com.chesshint.overlay.core.*;
import java.util.*;

public class TestEngine {
    static int fails = 0;
    static void check(String name, boolean ok, String extra) {
        System.out.println((ok ? "OK   " : "FAIL ") + name + (extra.isEmpty() ? "" : "  " + extra));
        if (!ok) fails++;
    }
    static void perft(String name, String fen, long... exp) {
        Position p = Position.fromFen(fen);
        for (int d = 1; d <= exp.length; d++) {
            long t0 = System.currentTimeMillis();
            long n = p.perft(d);
            check("perft " + name + " d" + d, n == exp[d - 1], n + " (ожидалось " + exp[d - 1] + ") " + (System.currentTimeMillis() - t0) + "мс");
        }
    }
    static boolean same3(String a, String b) { String[] x = a.split(" "), y = b.split(" "); return x[0].equals(y[0]) && x[1].equals(y[1]) && x[2].equals(y[2]); }
    public static void main(String[] a) throws Exception {
        perft("start", Position.START_FEN, 20, 400, 8902, 197281);
        perft("kiwipete", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1", 48, 2039, 97862);
        perft("pos3", "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1", 14, 191, 2812, 43238);
        perft("pos4", "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1", 6, 264, 9467);
        perft("pos5", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 44, 1486, 62379);

        // FEN туда-обратно
        Position k = Position.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1");
        check("fen roundtrip", k.toFen().equals("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"), k.toFen());

        Engine.Builtin eng = new Engine.Builtin();
        String[][] mates = {
            {"6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1", "a1a8"},                       // мат в 1
            {"r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4", "h5f7"},  // детский мат
            {"k7/8/1K6/8/8/8/8/7R w - - 0 1", "h1h8"},                                // Rh8#
        };
        for (String[] m : mates) {
            List<Engine.Line> ls = eng.analyze(Position.fromFen(m[0]), 3, 1000);
            Engine.Line l = ls.get(0);
            check("мат в 1 " + m[1], l.move.equals(m[1]) && l.mate == 1, l.move + " mate=" + l.mate + " d=" + l.depth);
        }
        // мат в 2: 1.Qb6+ axb6 2.Ra8#  (классика)
        String f2 = "kbK5/pp6/1P6/8/8/8/8/R7 w - - 0 1";
        List<Engine.Line> ls = eng.analyze(Position.fromFen(f2), 2, 3000);
        check("мат в 2 (a1a6)", ls.get(0).move.equals("a1a6") && ls.get(0).mate == 2, ls.get(0).move + " mate=" + ls.get(0).mate + " d=" + ls.get(0).depth);

        // тактика: выиграть ферзя вилкой коня
        Position fork = Position.fromFen("4k3/8/8/3q4/8/4N3/8/4K3 w - - 0 1");   // Nxd5? ферзь просто висит
        Engine.Line l = eng.analyze(fork, 3, 500).get(0);
        check("берёт повисшего ферзя", l.move.equals("e3d5"), l.move + " cp=" + l.cp);

        // MultiPV и сортировка
        ls = eng.analyze(Position.start(), 5, 800);
        boolean sorted = true;
        for (int i = 1; i < ls.size(); i++) if (Engine.score(ls.get(i)) > Engine.score(ls.get(i - 1))) sorted = false;
        StringBuilder sb = new StringBuilder();
        for (Engine.Line x : ls) sb.append(x.move).append(':').append(x.cp).append(' ');
        check("multipv=5 отсортирован", ls.size() == 5 && sorted, sb + "d=" + ls.get(0).depth);

        // скорость
        long t0 = System.currentTimeMillis();
        eng.analyze(Position.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"), 6, 800);
        check("укладывается во время (800мс)", System.currentTimeMillis() - t0 < 1300, (System.currentTimeMillis() - t0) + "мс");

        // уровни подсказок
        List<Engine.Line> six = eng.analyze(Position.fromFen("r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3"), 6, 800);
        Engine.Line b0 = Hints.pick(six, 0), b1 = Hints.pick(six, 1), b2 = Hints.pick(six, 2);
        check("уровни: лучший≥средний≥слабый", Engine.score(b0) >= Engine.score(b1) && Engine.score(b1) >= Engine.score(b2),
              b0.move + "(" + Engine.score(b0) + ") " + b1.move + "(" + Engine.score(b1) + ") " + b2.move + "(" + Engine.score(b2) + ")");

        // угрозы: чёрный конь вилкой/ферзь под боем
        Position th = Position.fromFen("rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3");
        Hints.Threats t = Hints.threats(th, eng, eng.analyze(th, 3, 400).get(0), 400);
        System.out.println("     угрозы: клетки=" + t.squares + " стрелки=" + t.arrows.size());
        List<Integer> hang = Hints.endangered(Position.fromFen("4k3/8/8/3p4/4P3/8/8/4K3 b - - 0 1"), false);
        check("повисшая пешка d5 найдена", hang.contains(Position.sqOf("d5")), hang.toString());

        // трекер: партия с взятием на проходе, рокировкой
        Tracker tr = new Tracker();
        Position p = Position.start();
        tr.update(p.b.clone());
        String[] game = {"e2e4","a7a6","e4e5","d7d5","e5d6","c7d6","g1f3","b8c6","f1c4","g8f6","e1g1","c8g4","d2d3","e7e6"};
        boolean ok = true;
        for (String mvs : game) {
            p.make(p.find(mvs));
            Tracker.Status s = tr.update(p.b.clone());
            if (s != Tracker.Status.UPDATED || !tr.cur.toFen().equals(p.toFen())) { ok = false; System.out.println("   сбой на " + mvs + " " + s + " " + tr.cur.toFen() + " vs " + p.toFen()); break; }
        }
        check("трекер: по ходам (ep, рокировка)", ok, tr.cur.toFen());
        // пропуск двух полуходов (ход игрока + ответ бота между сканами)
        Position q = Position.start();
        Tracker t2 = new Tracker(); t2.update(q.b.clone());
        q.make(q.find("d2d4")); q.make(q.find("g8f6")); q.make(q.find("c2c4")); q.make(q.find("e7e6"));
        check("трекер: 4 полухода за один кадр", t2.update(q.b.clone()) == Tracker.Status.UPDATED && same3(t2.cur.toFen(), q.toFen()), t2.cur.toFen());
        // включили посреди партии: трекер считает, что ходит игрок (белые), а на самом деле ходят чёрные
        Position mid = Position.fromFen("rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 2");
        Tracker t3 = new Tracker(); t3.update(mid.b.clone());
        check("трекер: угадал очередь (белые)", t3.cur.white, "");
        mid.make(mid.find("g8f6"));
        Tracker.Status s3 = t3.update(mid.b.clone());
        check("трекер: исправил очередь хода по первому ходу", s3 == Tracker.Status.UPDATED && same3(t3.cur.toFen(), mid.toFen()), s3 + " " + t3.cur.toFen());
        // переворот доски в приложении
        byte[] rot = new byte[64]; for (int i = 0; i < 64; i++) rot[i] = q.b[63 - i];
        Tracker.Status sf = t2.update(rot);
        check("трекер: переворот доски", sf == Tracker.Status.SAME && !t2.whiteBottom, sf + " whiteBottom=" + t2.whiteBottom);

        // парсер UCI
        Map<Integer, Engine.Line> m = new TreeMap<>();
        java.lang.reflect.Method pm = Class.forName("com.chesshint.overlay.core.UciAnalyzer").getDeclaredMethod("parseInfo", String.class, Map.class);
        pm.setAccessible(true);
        pm.invoke(null, "info depth 12 seldepth 18 multipv 1 score cp 34 nodes 1000 nps 100 time 5 pv e2e4 e7e5 g1f3", m);
        pm.invoke(null, "info depth 12 seldepth 18 multipv 2 score mate -3 nodes 1000 pv d2d4 d7d5", m);
        pm.invoke(null, "info depth 13 multipv 1 score cp 50 lowerbound pv e2e4", m);
        pm.invoke(null, "info depth 11 multipv 1 score cp 10 pv a2a3", m);
        check("UCI parseInfo", m.size() == 2 && m.get(1).move.equals("e2e4") && m.get(1).cp == 34 && m.get(2).mate == -3, m.get(1).move + " " + m.get(1).cp);
        System.out.println(fails == 0 ? "ВСЕ ТЕСТЫ ДВИЖКА ПРОЙДЕНЫ" : ("ПРОВАЛОВ: " + fails));
    }
}
