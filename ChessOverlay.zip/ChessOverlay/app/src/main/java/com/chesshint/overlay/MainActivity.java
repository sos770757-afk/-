package com.chesshint.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int RC_OVERLAY = 1, RC_CAPTURE = 2, RC_NOTIF = 3;
    private TextView tvState;
    private float d;

    private int dp(float v) { return (int) (v * d + 0.5f); }

    private TextView label(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    private TextView button(String t, int bg, View.OnClickListener l) {
        TextView v = label(t, 17, 0xFFFFFFFF, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(16), dp(14), dp(16), dp(14));
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(14));
        v.setBackground(g);
        v.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        v.setLayoutParams(lp);
        return v;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF101216);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(40), dp(22), dp(28));
        sv.addView(root);
        root.addView(label("♞  Шахматный помощник", 26, 0xFFFFFFFF, true));
        TextView sub = label("Оверлей для тренировки против ботов", 15, 0xFF9AA4B2, false);
        sub.setPadding(0, dp(4), 0, dp(18));
        root.addView(sub);
        root.addView(label(
                "1. Нажмите «Запустить» и разрешите показ поверх других приложений и запись экрана. "
                + "В окне записи выберите «Весь экран» (не «одно приложение»).\n\n"
                + "2. Откройте шахматное приложение и начните партию против бота с новой (стартовой) позиции. "
                + "Помощник сам найдёт доску и запомнит, как выглядят фигуры.\n\n"
                + "3. Зелёная стрелка — подсказка. Кнопка ♞ включает и выключает помощник, её можно перетащить. "
                + "Шестерёнка ⚙ открывает настройки: стиль подсказок, шкалу оценки и показ угроз.\n\n"
                + "Всё считается на устройстве, в интернет приложение ничего не отправляет. "
                + "Используйте только в играх против компьютера: в партиях с людьми подсказки движка — это жульничество.",
                15, 0xFFD5DAE1, false));
        tvState = label("", 14, 0xFFFFC857, false);
        tvState.setPadding(0, dp(16), 0, 0);
        root.addView(tvState);
        root.addView(button("Запустить", 0xFF2E9E5B, new View.OnClickListener() {
            @Override public void onClick(View v) { startFlow(); }
        }));
        root.addView(button("Остановить", 0xFF4A5160, new View.OnClickListener() {
            @Override public void onClick(View v) { stopService(new Intent(MainActivity.this, OverlayService.class)); }
        }));
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        tvState.setText(Settings.canDrawOverlays(this) ? "Разрешение «поверх других окон»: есть" : "Нужно разрешение «поверх других окон»");
    }

    private void startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), RC_OVERLAY);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIF);
            return;
        }
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), RC_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == RC_NOTIF) startFlow();
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == RC_OVERLAY) {
            if (Settings.canDrawOverlays(this)) startFlow();
        } else if (code == RC_CAPTURE && result == RESULT_OK && data != null) {
            Intent i = new Intent(this, OverlayService.class);
            i.putExtra("code", result);
            i.putExtra("data", data);
            startForegroundService(i);
            moveTaskToBack(true);
        }
    }
}
