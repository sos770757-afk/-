package com.chesshint.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Полноэкранный прозрачный слой: стрелки, красные подсветки угроз, шкала оценки и строка статуса. */
public class ArrowView extends View {
    public static final class Arrow {
        public float x1, y1, x2, y2, w;
        public int color;
    }

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float d;

    private List<Arrow> arrows = new ArrayList<>();
    private List<RectF> boxes = new ArrayList<>();
    private boolean evalOn;
    private String evalText = "";
    private float evalFrac = 0.5f;
    private String status = "";

    public ArrowView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextAlign(Paint.Align.CENTER);
        box.setStyle(Paint.Style.FILL);
        box.setColor(0x55FF1F1F);
    }

    public void setHints(List<Arrow> a, List<RectF> b) { arrows = a; boxes = b; invalidate(); }
    public void clearHints() { arrows = new ArrayList<>(); boxes = new ArrayList<>(); invalidate(); }
    public void setEval(boolean on, String t, float frac) { evalOn = on; evalText = t; evalFrac = frac; invalidate(); }
    public void setStatus(String s) { status = s == null ? "" : s; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        c.save();
        c.translate(-loc[0], -loc[1]);
        for (RectF r : boxes) c.drawRect(r, box);
        for (Arrow a : arrows) drawArrow(c, a);
        c.restore();

        float top = 34 * d, cx = getWidth() / 2f;
        if (evalOn && evalText.length() > 0) {
            float w = getWidth() * 0.6f, h = 22 * d, l = cx - w / 2;
            RectF rr = new RectF(l, top, l + w, top + h);
            path.reset();
            path.addRoundRect(rr, h / 2, h / 2, Path.Direction.CW);
            c.save();
            c.clipPath(path);
            fill.setColor(0xFF1B1B1F);
            c.drawRect(rr, fill);
            fill.setColor(0xFFF2F2F2);
            c.drawRect(l, top, l + w * evalFrac, top + h, fill);
            c.restore();
            stroke.setStrokeWidth(1.5f * d);
            stroke.setColor(0x99000000);
            c.drawRoundRect(rr, h / 2, h / 2, stroke);
            text.setTextSize(13 * d);
            float ty = top + h / 2 + 4.6f * d;
            text.setStyle(Paint.Style.STROKE);
            text.setStrokeWidth(3 * d);
            text.setColor(0xFF000000);
            c.drawText(evalText, cx, ty, text);
            text.setStyle(Paint.Style.FILL);
            text.setColor(0xFFFFFFFF);
            c.drawText(evalText, cx, ty, text);
            top += h + 6 * d;
        }
        if (status.length() > 0) {
            text.setTextSize(12.5f * d);
            text.setStyle(Paint.Style.FILL);
            float tw = text.measureText(status) + 24 * d, h = 26 * d;
            RectF rr = new RectF(cx - tw / 2, top, cx + tw / 2, top + h);
            fill.setColor(0xCC000000);
            c.drawRoundRect(rr, h / 2, h / 2, fill);
            text.setColor(0xFFFFFFFF);
            c.drawText(status, cx, top + h / 2 + 4.4f * d, text);
        }
    }

    private void drawArrow(Canvas c, Arrow a) {
        float dx = a.x2 - a.x1, dy = a.y2 - a.y1, len = (float) Math.hypot(dx, dy);
        if (len < 1) return;
        float ux = dx / len, uy = dy / len;
        float head = Math.min(len * 0.55f, a.w * 3.3f);
        float bx = a.x2 - ux * head, by = a.y2 - uy * head;
        fill.setColor(a.color);
        stroke.setColor(a.color);
        stroke.setStrokeWidth(a.w);
        c.drawLine(a.x1, a.y1, bx, by, stroke);
        path.reset();
        path.moveTo(a.x2, a.y2);
        path.lineTo(bx - uy * a.w * 1.4f, by + ux * a.w * 1.4f);
        path.lineTo(bx + uy * a.w * 1.4f, by - ux * a.w * 1.4f);
        path.close();
        c.drawPath(path, fill);
        c.drawCircle(a.x1, a.y1, a.w * 0.85f, fill);
    }
}
