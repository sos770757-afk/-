package com.chesshint.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import com.chesshint.overlay.core.Detector;
import com.chesshint.overlay.core.Engine;
import com.chesshint.overlay.core.Hints;
import com.chesshint.overlay.core.Position;
import com.chesshint.overlay.core.Tracker;
import com.chesshint.overlay.core.UciAnalyzer;

import java.io.File;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Оверлей-помощник: захват экрана (MediaProjection) → поиск доски → FEN → Stockfish → стрелки поверх экрана.
 * Свои стрелки попадают в захват, поэтому изменения доски определяются «отпечатком» с маской под стрелками,
 * а для распознавания берётся кадр, снятый, когда стрелки скрыты.
 */
public class OverlayService extends Service {
    private static final String TAG = "ChessHint";
    private static final String CHANNEL = "chesshint";
    private static final String[] LEVELS = {"Лучшие ходы", "Средние ходы", "Ошибки / слабые ходы"};

    private Handler main;
    private WindowManager wm;
    private SharedPreferences prefs;
    private ContextThemeWrapper ui;
    private float dens;

    // окна
    private ArrowView arrows;
    private LinearLayout controls, panel;
    private WindowManager.LayoutParams lpControls, lpPanel;
    private TextView tvInfo, tvLevel;
    private GradientDrawable btnBg;
    private boolean panelShown;

    // захват экрана
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private int sw, sh, dpi;
    private Bitmap frameBmp;
    private int frameW, frameH;
    private int[] fullBuf;
    private ByteBuffer padBuf;

    // потоки и движок
    private HandlerThread scanThread;
    private Handler scan;
    private final ExecutorService engineExec = Executors.newSingleThreadExecutor();
    private volatile Engine.Analyzer analyzer;
    private volatile boolean destroyed;

    // настройки
    private volatile int level;
    private volatile boolean evalOn, threatsOn, paused, rescan;
    private volatile boolean active = true;

    // состояние сканера (поток scan)
    private Detector.Geo geo, lg;
    private Detector.PieceSet pieces;
    private final Tracker tracker = new Tracker();
    private int[] roi;
    private int roiX, roiY, roiW, roiH;
    private int fpN;
    private int[] fpX, fpY, fp, fpPrev;
    private boolean[] mask;
    private Object maskSrc;
    private long lastChange, lastFind, lastSizeCheck;
    private boolean needAnalysis;
    private int staticRetries;

    private final Object hintLock = new Object();
    private volatile boolean hintsOn;
    private volatile long hiddenAt;
    private volatile int gen;
    private volatile Shown shown;
    private volatile Cache cache;
    private volatile String lastEvalText = "";
    private volatile float lastEvalFrac = 0.5f;
    private volatile String infoStatus = "";

    private static final class Shown {
        final List<ArrowView.Arrow> arrows;
        final List<RectF> boxes;
        Shown(List<ArrowView.Arrow> a, List<RectF> b) { arrows = a; boxes = b; }
    }

    private static final class Cache {
        Position pos;
        boolean userWhite;
        List<Engine.Line> lines;
        Hints.Threats th;
        int gen;
        Detector.Geo geo;
        String evalText;
        float evalFrac;
    }

    // ------------------------------------------------------------------ жизненный цикл
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        main = new Handler(Looper.getMainLooper());
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = getSharedPreferences("chesshint", MODE_PRIVATE);
        dens = getResources().getDisplayMetrics().density;
        ui = new ContextThemeWrapper(this, android.R.style.Theme_Material);
        level = prefs.getInt("level", 0);
        evalOn = prefs.getBoolean("eval", true);
        threatsOn = prefs.getBoolean("threats", false);
        tracker.whiteBottom = prefs.getBoolean("whiteBottom", true);
        pieces = Detector.PieceSet.load(new File(getFilesDir(), "pieces.bin"));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;
        try {
            startForegroundCompat();
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    main.post(new Runnable() { @Override public void run() { stopSelf(); } });
                }
            }, main);
            setupCapture();
            buildUi();
            initEngine();
            scanThread = new HandlerThread("chess-scan");
            scanThread.start();
            scan = new Handler(scanThread.getLooper());
            scan.postDelayed(tick, 400);
            status("Ищу шахматную доску…");
        } catch (Throwable t) {
            Log.e(TAG, "start failed", t);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        destroyed = true;
        super.onDestroy();
        if (scan != null) scan.removeCallbacksAndMessages(null);
        if (scanThread != null) scanThread.quitSafely();
        try { if (panelShown) wm.removeView(panel); } catch (Throwable ignored) { }
        try { if (controls != null) wm.removeView(controls); } catch (Throwable ignored) { }
        try { if (arrows != null) wm.removeView(arrows); } catch (Throwable ignored) { }
        try { if (vd != null) vd.release(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) { }
        engineExec.shutdownNow();
        Engine.Analyzer a = analyzer;
        if (a != null) a.close();
    }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Шахматный помощник", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, OverlayService.class).setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Шахматный помощник работает")
                .setContentText("Нажмите, чтобы выключить")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(7, n);
    }

    private void setupCapture() {
        DisplayMetrics dm = realMetrics();
        sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi;
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2);
        vd = projection.createVirtualDisplay("chesshint", sw, sh, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
    }

    private DisplayMetrics realMetrics() {
        Display d = ((DisplayManager) getSystemService(Context.DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics dm = new DisplayMetrics();
        d.getRealMetrics(dm);
        return dm;
    }

    /** Поворот экрана: меняем размер того же VirtualDisplay (второй createVirtualDisplay на Android 14 запрещён). */
    private void checkSize() {
        DisplayMetrics dm = realMetrics();
        if (dm.widthPixels == sw && dm.heightPixels == sh) return;
        ImageReader nr = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2);
        vd.resize(dm.widthPixels, dm.heightPixels, dm.densityDpi);
        vd.setSurface(nr.getSurface());
        ImageReader old = reader;
        reader = nr; sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi;
        if (old != null) old.close();
        frameBmp = null; frameW = 0; frameH = 0; geo = null; fpPrev = null;
        synchronized (hintLock) { shown = null; hintsOn = false; gen++; }
        main.post(new Runnable() { @Override public void run() { if (arrows != null) arrows.clearHints(); } });
    }

    // ------------------------------------------------------------------ интерфейс
    private int dp(float v) { return (int) (v * dens + 0.5f); }

    private TextView txt(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(ui);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable circleBg(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(dp(2), 0x66FFFFFF);
        return g;
    }

    private TextView circle(String t, GradientDrawable bg, int size, float sp) {
        TextView v = txt(t, sp, 0xFFFFFFFF, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(bg);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return v;
    }

    private TextView action(String t, int color, View.OnClickListener l) {
        TextView v = txt(t, 14, 0xFFFFFFFF, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        v.setBackground(g);
        v.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        v.setLayoutParams(lp);
        return v;
    }

    private WindowManager.LayoutParams winParams(int w, int h, int flags) {
        return new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
    }

    private void buildUi() {
        arrows = new ArrowView(this);
        WindowManager.LayoutParams lpA = winParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        lpA.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) lpA.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(arrows, lpA);

        btnBg = circleBg(0xFF2E9E5B);
        TextView btnMain = circle("♞", btnBg, 52, 24);
        TextView gear = circle("⚙", circleBg(0xFF3A4150), 40, 19);
        controls = new LinearLayout(ui);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.addView(btnMain);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(40), dp(40));
        gp.leftMargin = dp(8);
        controls.addView(gear, gp);
        lpControls = winParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        lpControls.gravity = Gravity.TOP | Gravity.START;
        lpControls.x = prefs.getInt("cx", dp(8));
        lpControls.y = prefs.getInt("cy", dp(110));
        wm.addView(controls, lpControls);

        btnMain.setOnTouchListener(new View.OnTouchListener() {
            float offX, offY, sx, sy;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY();
                        offX = lpControls.x - sx; offY = lpControls.y - sy;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - sx) + Math.abs(e.getRawY() - sy) > dp(8)) moved = true;
                        if (moved) {
                            lpControls.x = (int) (e.getRawX() + offX);
                            lpControls.y = (int) (e.getRawY() + offY);
                            wm.updateViewLayout(controls, lpControls);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) prefs.edit().putInt("cx", lpControls.x).putInt("cy", lpControls.y).apply();
                        else toggleActive();
                        return true;
                    default:
                        return true;
                }
            }
        });
        gear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { togglePanel(); }
        });
        buildPanel();
    }

    private void buildPanel() {
        panel = new LinearLayout(ui);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2171A21);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0x33FFFFFF);
        panel.setBackground(bg);

        panel.addView(txt("⚙  Настройки подсказок", 16, 0xFFFFFFFF, true));
        TextView cap = txt("Сила и стиль ходов", 12.5f, 0xFF9AA4B2, false);
        cap.setPadding(0, dp(12), 0, 0);
        panel.addView(cap);
        tvLevel = txt(LEVELS[level], 15, 0xFF5BE38F, true);
        panel.addView(tvLevel);
        SeekBar sb = new SeekBar(ui);
        sb.setMax(2);
        sb.setProgress(level);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                level = p;
                tvLevel.setText(LEVELS[p]);
                prefs.edit().putInt("level", p).apply();
                if (fromUser) republish();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        panel.addView(sb);

        Switch swEval = new Switch(ui);
        swEval.setText("Шкала оценки (в пешках)");
        swEval.setTextColor(0xFFFFFFFF);
        swEval.setChecked(evalOn);
        swEval.setPadding(0, dp(8), 0, dp(4));
        swEval.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                evalOn = on;
                prefs.edit().putBoolean("eval", on).apply();
                if (arrows != null && active) arrows.setEval(on, lastEvalText, lastEvalFrac);
            }
        });
        panel.addView(swEval);

        Switch swThreat = new Switch(ui);
        swThreat.setText("Угрозы и опасность (красным)");
        swThreat.setTextColor(0xFFFFFFFF);
        swThreat.setChecked(threatsOn);
        swThreat.setPadding(0, dp(8), 0, dp(4));
        swThreat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                threatsOn = on;
                prefs.edit().putBoolean("threats", on).apply();
                rescan = true;
            }
        });
        panel.addView(swThreat);

        panel.addView(action("Перевернуть доску", 0xFF3A4150, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Handler h = scan;
                if (h != null) h.post(new Runnable() {
                    @Override public void run() {
                        tracker.whiteBottom = !tracker.whiteBottom;
                        tracker.cur = null;
                        saveSide();
                        rescan = true;
                    }
                });
                closePanel();
            }
        }));
        panel.addView(action("Пересканировать", 0xFF3A4150, new View.OnClickListener() {
            @Override public void onClick(View v) { rescan = true; closePanel(); }
        }));
        panel.addView(action("Выключить помощник", 0xFF8A2E2E, new View.OnClickListener() {
            @Override public void onClick(View v) { stopSelf(); }
        }));
        tvInfo = txt("", 12, 0xFF9AA4B2, false);
        tvInfo.setPadding(0, dp(10), 0, 0);
        panel.addView(tvInfo);

        lpPanel = winParams(dp(290), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        lpPanel.gravity = Gravity.TOP | Gravity.START;
    }

    private void togglePanel() {
        if (panelShown) { closePanel(); return; }
        lpPanel.x = lpControls.x;
        lpPanel.y = Math.max(0, Math.min(lpControls.y + dp(62), sh - dp(400)));
        wm.addView(panel, lpPanel);
        panelShown = true;
        paused = true;
        refreshInfo();
    }

    private void closePanel() {
        if (!panelShown) return;
        try { wm.removeView(panel); } catch (Throwable ignored) { }
        panelShown = false;
        paused = false;
    }

    private void toggleActive() {
        active = !active;
        btnBg.setColor(active ? 0xFF2E9E5B : 0xFF6B7280);
        if (!active) {
            synchronized (hintLock) { hintsOn = false; shown = null; gen++; }
            arrows.clearHints();
            arrows.setEval(false, "", 0.5f);
            arrows.setStatus("");
        } else {
            arrows.setEval(evalOn, lastEvalText, lastEvalFrac);
            rescan = true;
        }
    }

    private void status(final String s) {
        infoStatus = s;
        main.post(new Runnable() {
            @Override public void run() {
                if (arrows != null) arrows.setStatus(active ? s : "");
                refreshInfo();
            }
        });
    }

    private void refreshInfo() {
        if (tvInfo == null) return;
        Engine.Analyzer a = analyzer;
        tvInfo.setText("Движок: " + (a == null ? "загрузка…" : a.name())
                + (infoStatus.length() > 0 ? "\n" + infoStatus : "\nДоска распознана"));
    }

    private void saveSide() { prefs.edit().putBoolean("whiteBottom", tracker.whiteBottom).apply(); }

    // ------------------------------------------------------------------ движок
    private void initEngine() {
        engineExec.execute(new Runnable() {
            @Override public void run() {
                Engine.Analyzer a = null;
                File sf = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so");
                if (sf.exists()) {
                    try {
                        int th = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1));
                        a = new UciAnalyzer(new String[]{sf.getAbsolutePath()}, "Stockfish", th, 64);
                    } catch (Throwable t) {
                        Log.w(TAG, "stockfish failed, using built-in", t);
                        a = null;
                    }
                }
                if (a == null) a = new Engine.Builtin();
                analyzer = a;
                main.post(new Runnable() { @Override public void run() { refreshInfo(); } });
            }
        });
    }

    private void runEngine(final Position pos, final boolean userWhite, final int g0, final Detector.Geo g) {
        Engine.Analyzer an = analyzer;
        if (an == null) an = new Engine.Builtin();
        boolean myTurn = pos.white == userWhite;
        try {
            List<Engine.Line> lines = an.analyze(pos, myTurn ? 6 : 1, myTurn ? 900 : 300);
            if (g0 != gen || destroyed) return;
            if (lines.isEmpty()) { status(pos.inCheck() ? "Мат — партия окончена" : "Пат — партия окончена"); return; }
            Engine.Line top = lines.get(0);
            Hints.Threats th = null;
            if (threatsOn && myTurn) th = Hints.threats(pos, an, top, 350);
            if (g0 != gen || destroyed) return;
            Cache c = new Cache();
            c.pos = pos; c.userWhite = userWhite; c.lines = lines; c.th = th; c.gen = g0; c.geo = g;
            float pawns = Hints.pawnsWhite(top, pos.white);
            c.evalText = Hints.evalText(top, pos.white);
            c.evalFrac = (float) (1.0 / (1.0 + Math.exp(-pawns / 2.5)));
            cache = c;
            status(myTurn ? "" : "Ход соперника…");
            publish(c);
        } catch (Throwable t) {
            Log.w(TAG, "engine failed", t);
            if (!(an instanceof Engine.Builtin)) {
                analyzer = new Engine.Builtin();
                an.close();
                runEngine(pos, userWhite, g0, g);
            }
        }
    }

    private void republish() {
        engineExec.execute(new Runnable() {
            @Override public void run() {
                Cache c = cache;
                if (c != null && c.gen == gen && !destroyed) publish(c);
            }
        });
    }

    private void publish(final Cache c) {
        List<ArrowView.Arrow> as = new ArrayList<>();
        List<RectF> bx = new ArrayList<>();
        boolean myTurn = c.pos.white == c.userWhite;
        Engine.Line pick = Hints.pick(c.lines, level);
        if (myTurn && pick != null && pick.move.length() >= 4) {
            as.add(arrow(c.geo, c.userWhite, Position.sqOf(pick.move.substring(0, 2)), Position.sqOf(pick.move.substring(2, 4)), 0xE62ECC71));
        }
        if (threatsOn && c.th != null) {
            for (int[] t : c.th.arrows) as.add(arrow(c.geo, c.userWhite, t[0], t[1], 0xEEFF2A2A));
            for (int sq : c.th.squares) bx.add(cellRect(c.geo, c.userWhite, sq));
        }
        final Shown sh = new Shown(as, bx);
        synchronized (hintLock) {
            if (c.gen != gen || destroyed) return;    // позиция уже изменилась — устаревшие стрелки не показываем
            shown = sh;
            hintsOn = !as.isEmpty() || !bx.isEmpty();
            lastEvalText = c.evalText;
            lastEvalFrac = c.evalFrac;
            main.post(new Runnable() {
                @Override public void run() {
                    if (destroyed || !active || arrows == null) return;
                    arrows.setHints(sh.arrows, sh.boxes);
                    arrows.setEval(evalOn, c.evalText, c.evalFrac);
                }
            });
        }
    }

    private static float[] center(Detector.Geo g, boolean whiteBottom, int sq) {
        int f = sq & 7, r = sq >> 3;
        int col = whiteBottom ? f : 7 - f, row = whiteBottom ? 7 - r : r;
        return new float[]{g.x + (col + 0.5f) * g.cell, g.y + (row + 0.5f) * g.cell};
    }

    private static ArrowView.Arrow arrow(Detector.Geo g, boolean wb, int from, int to, int color) {
        ArrowView.Arrow a = new ArrowView.Arrow();
        float[] p = center(g, wb, from), q = center(g, wb, to);
        a.x1 = p[0]; a.y1 = p[1]; a.x2 = q[0]; a.y2 = q[1];
        a.w = g.cell * 0.12f;
        a.color = color;
        return a;
    }

    private static RectF cellRect(Detector.Geo g, boolean wb, int sq) {
        float[] c = center(g, wb, sq);
        float h = g.cell / 2f;
        return new RectF(c[0] - h, c[1] - h, c[0] + h, c[1] + h);
    }

    // ------------------------------------------------------------------ сканирование (поток scan)
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            try { step(); } catch (Throwable t) { Log.e(TAG, "step", t); }
            Handler h = scan;
            if (!destroyed && h != null) h.postDelayed(this, 150);
        }
    };

    private void step() {
        if (!active) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastSizeCheck > 2000) { lastSizeCheck = now; checkSize(); }
        boolean fresh = grabFrame();
        if (paused || frameBmp == null) return;
        if (geo == null) {
            if (fresh || rescan) staticRetries = 0;
            if (now - lastFind > (fresh || rescan ? 1500 : 4000) && (fresh || rescan || staticRetries < 3)) {
                if (!fresh && !rescan) staticRetries++;
                rescan = false;
                lastFind = now;
                findBoard(now);
            }
            return;
        }
        if (fresh) {
            frameBmp.getPixels(roi, 0, roiW, roiX, roiY, roiW, roiH);
            if (fingerprintChanged()) boardChanged(now);
        }
        if (rescan) { rescan = false; boardChanged(now); }
        if (needAnalysis && !hintsOn && now - lastChange >= 380 && now - hiddenAt >= 250) {
            needAnalysis = false;
            analyze();
        }
    }

    private void boardChanged(long now) {
        boolean hide;
        synchronized (hintLock) {
            gen++;
            hide = hintsOn;
            if (hide) {
                hintsOn = false;
                shown = null;
                hiddenAt = now;
                main.post(new Runnable() { @Override public void run() { if (arrows != null) arrows.clearHints(); } });
            }
        }
        lastChange = now;
        needAnalysis = true;
    }

    private boolean grabFrame() {
        ImageReader r = reader;
        if (r == null) return false;
        Image img = null;
        try { img = r.acquireLatestImage(); } catch (Throwable t) { return false; }
        if (img == null) return false;
        try {
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int ps = pl.getPixelStride(), rs = pl.getRowStride(), w = img.getWidth(), h = img.getHeight();
            int bw = rs / ps;
            if (frameBmp == null || frameBmp.getWidth() != bw || frameBmp.getHeight() != h) frameBmp = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888);
            buf.rewind();
            int need = bw * h * 4;
            if (buf.remaining() >= need) {
                frameBmp.copyPixelsFromBuffer(buf);
            } else {
                if (padBuf == null || padBuf.capacity() != need) padBuf = ByteBuffer.allocateDirect(need);
                padBuf.clear();
                padBuf.put(buf);
                padBuf.rewind();
                frameBmp.copyPixelsFromBuffer(padBuf);
            }
            frameW = w; frameH = h;
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "frame copy failed", t);
            return false;
        } finally {
            img.close();
        }
    }

    private void findBoard(long now) {
        if (frameW <= 0 || frameH <= 0) return;
        if (fullBuf == null || fullBuf.length != frameW * frameH) fullBuf = new int[frameW * frameH];
        frameBmp.getPixels(fullBuf, 0, frameW, 0, 0, frameW, frameH);
        Detector.Geo g = Detector.find(fullBuf, frameW, frameH);
        if (g == null) { status("Ищу шахматную доску…"); return; }
        setGeometry(g);
        frameBmp.getPixels(roi, 0, roiW, roiX, roiY, roiW, roiH);
        lastChange = now - 400;
        needAnalysis = true;
        gen++;
        status("Доска найдена");
    }

    private void setGeometry(Detector.Geo g) {
        geo = g;
        roiX = Math.max(0, (int) Math.floor(g.x) - 4);
        roiY = Math.max(0, (int) Math.floor(g.y) - 4);
        int x2 = Math.min(frameW, (int) Math.ceil(g.x + 8 * g.cell) + 4);
        int y2 = Math.min(frameH, (int) Math.ceil(g.y + 8 * g.cell) + 4);
        roiW = x2 - roiX;
        roiH = y2 - roiY;
        lg = new Detector.Geo();
        lg.x = g.x - roiX; lg.y = g.y - roiY; lg.cell = g.cell; lg.light = g.light; lg.dark = g.dark;
        roi = new int[roiW * roiH];
        int st = Math.max(4, Math.round(g.cell / 12f));
        int nx = (roiW + st - 1) / st, ny = (roiH + st - 1) / st;
        fpN = nx * ny;
        fpX = new int[fpN]; fpY = new int[fpN]; fp = new int[fpN];
        int k = 0;
        for (int y = 0; y < roiH; y += st) for (int x = 0; x < roiW; x += st) { fpX[k] = x; fpY[k] = y; k++; }
        fpPrev = null; mask = null; maskSrc = null;
    }

    private static boolean nearSeg(float px, float py, ArrowView.Arrow a, float r) {
        float dx = a.x2 - a.x1, dy = a.y2 - a.y1, l2 = dx * dx + dy * dy;
        float t = l2 == 0 ? 0 : ((px - a.x1) * dx + (py - a.y1) * dy) / l2;
        t = Math.max(0f, Math.min(1f, t));
        float qx = a.x1 + t * dx - px, qy = a.y1 + t * dy - py;
        return qx * qx + qy * qy <= r * r;
    }

    private boolean[] buildMask(Shown s) {
        boolean[] m = new boolean[fpN];
        if (s == null) return m;
        for (int k = 0; k < fpN; k++) {
            float x = roiX + fpX[k], y = roiY + fpY[k];
            boolean hit = false;
            for (RectF r : s.boxes) if (r.contains(x, y)) { hit = true; break; }
            if (!hit) for (ArrowView.Arrow a : s.arrows) if (nearSeg(x, y, a, a.w * 1.7f + 4)) { hit = true; break; }
            m[k] = hit;
        }
        return m;
    }

    /** «Отпечаток» доски: яркость в сетке точек; точки под нашими стрелками не сравниваются. */
    private boolean fingerprintChanged() {
        Shown s = shown;
        if (mask == null || s != maskSrc) { mask = buildMask(s); maskSrc = s; }
        for (int k = 0; k < fpN; k++) fp[k] = Detector.lum(roi[fpY[k] * roiW + fpX[k]]);
        if (fpPrev == null) { fpPrev = fp.clone(); return false; }
        int diff = 0;
        for (int k = 0; k < fpN; k++) if (!mask[k] && Math.abs(fp[k] - fpPrev[k]) > 24) diff++;
        System.arraycopy(fp, 0, fpPrev, 0, fpN);
        return diff > 8;
    }

    private void analyze() {
        if (!Detector.check(lg, roi, roiW, roiH)) {
            geo = null;
            lastFind = 0;
            status("Ищу шахматную доску…");
            return;
        }
        boolean sideBefore = tracker.whiteBottom;
        Detector.Scan r = Detector.scan(roi, roiW, roiH, lg, pieces, tracker.whiteBottom);
        if (r.learned) {
            tracker.whiteBottom = r.whiteBottom;
            try { pieces.save(new File(getFilesDir(), "pieces.bin")); } catch (Throwable t) { Log.w(TAG, "save pieces", t); }
        }
        if (r.board == null) {
            status("need_start".equals(r.problem)
                    ? "Начните новую партию — запомню вид фигур"
                    : "Не удалось распознать фигуры");
            return;
        }
        Tracker.Status st = tracker.update(r.board);
        if (tracker.whiteBottom != sideBefore) saveSide();
        if (st == Tracker.Status.INVALID || tracker.cur == null) { status("Позиция не распознана"); return; }
        final Position pos = tracker.cur.copy();
        final boolean userWhite = tracker.whiteBottom;
        final int g0 = gen;
        final Detector.Geo g = geo;
        engineExec.execute(new Runnable() {
            @Override public void run() { runEngine(pos, userWhite, g0, g); }
        });
    }
}
