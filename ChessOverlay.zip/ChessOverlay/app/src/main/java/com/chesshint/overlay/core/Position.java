package com.chesshint.overlay.core;

import java.util.Arrays;

/** Позиция. Поле: a1=0 ... h8=63 (sq = rank*8 + file). Фигуры: 1..6 = P,N,B,R,Q,K (белые), +8 = чёрные. */
public final class Position {
    public static final int P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
    public static final String START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

    public final byte[] b = new byte[64];
    public boolean white = true;   // чей ход
    public int castle = 15;        // 1=K 2=Q 4=k 8=q
    public int ep = -1;            // поле «на проходе»
    public int half = 0, full = 1;

    private static final int[] KDR = {-2, -2, -1, -1, 1, 1, 2, 2}, KDF = {-1, 1, -2, 2, -2, 2, -1, 1};
    private static final int[] DR = {1, -1, 0, 0, 1, 1, -1, -1}, DF = {0, 0, 1, -1, 1, -1, 1, -1};
    private static final int[] CMASK = new int[64];
    static {
        Arrays.fill(CMASK, 15);
        CMASK[0] = 13; CMASK[4] = 12; CMASK[7] = 14;
        CMASK[56] = 7; CMASK[60] = 3; CMASK[63] = 11;
    }

    public static int mv(int from, int to, int promo) { return from | (to << 6) | (promo << 12); }
    public static int from(int m) { return m & 63; }
    public static int to(int m) { return (m >> 6) & 63; }
    public static int promo(int m) { return (m >> 12) & 7; }
    public static String sqName(int s) { return "" + (char) ('a' + (s & 7)) + (char) ('1' + (s >> 3)); }
    public static int sqOf(String s) { return (s.charAt(1) - '1') * 8 + (s.charAt(0) - 'a'); }
    public static String uci(int m) {
        String s = sqName(from(m)) + sqName(to(m));
        int p = promo(m);
        return p == 0 ? s : s + "?pnbrqk".charAt(p);
    }

    public static Position start() { return fromFen(START_FEN); }

    public static Position fromFen(String fen) {
        Position p = new Position();
        String[] t = fen.trim().split("\\s+");
        String[] rows = t[0].split("/");
        if (rows.length != 8) throw new IllegalArgumentException("fen");
        for (int i = 0; i < 8; i++) {
            int r = 7 - i, f = 0;
            for (char c : rows[i].toCharArray()) {
                if (c >= '1' && c <= '8') f += c - '0';
                else {
                    int idx = "pnbrqk".indexOf(Character.toLowerCase(c));
                    if (idx < 0 || f > 7) throw new IllegalArgumentException("fen");
                    int ty = idx + 1;
                    p.b[r * 8 + f++] = (byte) (Character.isUpperCase(c) ? ty : ty | 8);
                }
            }
        }
        p.white = t.length < 2 || t[1].equals("w");
        p.castle = 0;
        if (t.length > 2) for (char c : t[2].toCharArray()) {
            if (c == 'K') p.castle |= 1; else if (c == 'Q') p.castle |= 2;
            else if (c == 'k') p.castle |= 4; else if (c == 'q') p.castle |= 8;
        }
        p.ep = t.length > 3 && !t[3].equals("-") ? sqOf(t[3]) : -1;
        if (t.length > 4) p.half = Integer.parseInt(t[4]);
        if (t.length > 5) p.full = Integer.parseInt(t[5]);
        return p;
    }

    /** Позиция по голой расстановке; права рокировки угадываются по стоянию фигур. */
    public static Position fromPlacement(byte[] pl, boolean whiteToMove) {
        Position p = new Position();
        System.arraycopy(pl, 0, p.b, 0, 64);
        p.white = whiteToMove;
        p.castle = 0;
        if (p.b[4] == K) { if (p.b[7] == R) p.castle |= 1; if (p.b[0] == R) p.castle |= 2; }
        if (p.b[60] == (8 | K)) { if (p.b[63] == (8 | R)) p.castle |= 4; if (p.b[56] == (8 | R)) p.castle |= 8; }
        return p;
    }

    public String toFen() {
        StringBuilder sb = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int e = 0;
            for (int f = 0; f < 8; f++) {
                int pc = b[r * 8 + f];
                if (pc == 0) { e++; continue; }
                if (e > 0) { sb.append(e); e = 0; }
                char c = "pnbrqk".charAt((pc & 7) - 1);
                sb.append((pc & 8) == 0 ? Character.toUpperCase(c) : c);
            }
            if (e > 0) sb.append(e);
            if (r > 0) sb.append('/');
        }
        sb.append(white ? " w " : " b ");
        String cs = "";
        if ((castle & 1) != 0) cs += "K"; if ((castle & 2) != 0) cs += "Q";
        if ((castle & 4) != 0) cs += "k"; if ((castle & 8) != 0) cs += "q";
        sb.append(cs.isEmpty() ? "-" : cs).append(' ').append(ep < 0 ? "-" : sqName(ep));
        sb.append(' ').append(half).append(' ').append(full);
        return sb.toString();
    }

    public Position copy() {
        Position p = new Position();
        System.arraycopy(b, 0, p.b, 0, 64);
        p.white = white; p.castle = castle; p.ep = ep; p.half = half; p.full = full;
        return p;
    }

    public boolean samePlacement(byte[] o) { return Arrays.equals(b, o); }

    public int kingSq(boolean w) {
        int k = w ? K : (8 | K);
        for (int i = 0; i < 64; i++) if (b[i] == k) return i;
        return -1;
    }

    public boolean inCheck() { int k = kingSq(white); return k >= 0 && attacked(k, !white); }

    /** Атакует ли сторона byWhite поле sq. */
    public boolean attacked(int sq, boolean byWhite) {
        int r = sq >> 3, f = sq & 7, base = byWhite ? 0 : 8;
        int pr = byWhite ? r - 1 : r + 1;
        if (pr >= 0 && pr < 8) {
            if (f > 0 && b[pr * 8 + f - 1] == (base | P)) return true;
            if (f < 7 && b[pr * 8 + f + 1] == (base | P)) return true;
        }
        for (int k = 0; k < 8; k++) {
            int rr = r + KDR[k], ff = f + KDF[k];
            if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && b[rr * 8 + ff] == (base | N)) return true;
            rr = r + DR[k]; ff = f + DF[k];
            if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && b[rr * 8 + ff] == (base | K)) return true;
        }
        for (int d = 0; d < 8; d++) {
            int rr = r + DR[d], ff = f + DF[d];
            while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
                int pc = b[rr * 8 + ff];
                if (pc != 0) {
                    if ((pc & 8) == base) { int t = pc & 7; if (t == Q || (d < 4 ? t == R : t == B)) return true; }
                    break;
                }
                rr += DR[d]; ff += DF[d];
            }
        }
        return false;
    }

    private static int addPawn(int[] buf, int n, int from, int to, boolean promo) {
        if (promo) { buf[n++] = mv(from, to, Q); buf[n++] = mv(from, to, R); buf[n++] = mv(from, to, B); buf[n++] = mv(from, to, N); }
        else buf[n++] = mv(from, to, 0);
        return n;
    }

    /** Псевдолегальные ходы в buf (минимум 320 ячеек). */
    int gen(int[] buf) {
        int n = 0, us = white ? 0 : 8;
        for (int sq = 0; sq < 64; sq++) {
            int pc = b[sq];
            if (pc == 0 || (pc & 8) != us) continue;
            int t = pc & 7, r = sq >> 3, f = sq & 7;
            if (t == P) {
                int dir = white ? 1 : -1, r1 = r + dir;
                if (r1 < 0 || r1 > 7) continue;
                boolean pr = r1 == 0 || r1 == 7;
                if (b[r1 * 8 + f] == 0) {
                    n = addPawn(buf, n, sq, r1 * 8 + f, pr);
                    if (r == (white ? 1 : 6) && b[(r + 2 * dir) * 8 + f] == 0) buf[n++] = mv(sq, (r + 2 * dir) * 8 + f, 0);
                }
                for (int df = -1; df <= 1; df += 2) {
                    int ff = f + df;
                    if (ff < 0 || ff > 7) continue;
                    int to = r1 * 8 + ff, tp = b[to];
                    if (tp != 0 && (tp & 8) != us) n = addPawn(buf, n, sq, to, pr);
                    else if (tp == 0 && to == ep) buf[n++] = mv(sq, to, 0);
                }
            } else if (t == N || t == K) {
                for (int k = 0; k < 8; k++) {
                    int rr = r + (t == N ? KDR[k] : DR[k]), ff = f + (t == N ? KDF[k] : DF[k]);
                    if (rr < 0 || rr > 7 || ff < 0 || ff > 7) continue;
                    int tp = b[rr * 8 + ff];
                    if (tp == 0 || (tp & 8) != us) buf[n++] = mv(sq, rr * 8 + ff, 0);
                }
            } else {
                int d0 = t == B ? 4 : 0, d1 = t == R ? 4 : 8;
                for (int d = d0; d < d1; d++) {
                    int rr = r + DR[d], ff = f + DF[d];
                    while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
                        int tp = b[rr * 8 + ff];
                        if (tp == 0) buf[n++] = mv(sq, rr * 8 + ff, 0);
                        else { if ((tp & 8) != us) buf[n++] = mv(sq, rr * 8 + ff, 0); break; }
                        rr += DR[d]; ff += DF[d];
                    }
                }
            }
        }
        if (white) {
            if ((castle & 1) != 0 && b[4] == K && b[7] == R && b[5] == 0 && b[6] == 0
                    && !attacked(4, false) && !attacked(5, false) && !attacked(6, false)) buf[n++] = mv(4, 6, 0);
            if ((castle & 2) != 0 && b[4] == K && b[0] == R && b[1] == 0 && b[2] == 0 && b[3] == 0
                    && !attacked(4, false) && !attacked(3, false) && !attacked(2, false)) buf[n++] = mv(4, 2, 0);
        } else {
            int bk = 8 | K, br = 8 | R;
            if ((castle & 4) != 0 && b[60] == bk && b[63] == br && b[61] == 0 && b[62] == 0
                    && !attacked(60, true) && !attacked(61, true) && !attacked(62, true)) buf[n++] = mv(60, 62, 0);
            if ((castle & 8) != 0 && b[60] == bk && b[56] == br && b[57] == 0 && b[58] == 0 && b[59] == 0
                    && !attacked(60, true) && !attacked(59, true) && !attacked(58, true)) buf[n++] = mv(60, 58, 0);
        }
        return n;
    }

    public int[] legal() {
        int[] buf = new int[320];
        int n = gen(buf), k = 0;
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            Position q = copy();
            q.make(buf[i]);
            int ks = q.kingSq(white);
            if (ks >= 0 && q.attacked(ks, !white)) continue;
            out[k++] = buf[i];
        }
        return Arrays.copyOf(out, k);
    }

    public void make(int m) {
        int from = from(m), to = to(m), promo = promo(m);
        int pc = b[from], t = pc & 7, cap = b[to];
        boolean us = (pc & 8) == 0;
        int oldEp = ep;
        ep = -1;
        half++;
        if (t == P || cap != 0) half = 0;
        b[to] = (byte) pc; b[from] = 0;
        if (t == P) {
            if (to == oldEp && cap == 0 && (from & 7) != (to & 7)) b[us ? to - 8 : to + 8] = 0;
            if (Math.abs(to - from) == 16) ep = (from + to) / 2;
            if (promo != 0) b[to] = (byte) (promo | (pc & 8));
        }
        if (t == K && Math.abs(to - from) == 2) {
            if (to > from) { b[to - 1] = b[to + 1]; b[to + 1] = 0; }
            else { b[to + 1] = b[to - 2]; b[to - 2] = 0; }
        }
        castle &= CMASK[from] & CMASK[to];
        if (!us) full++;
        white = !white;
    }

    /** Найти легальный ход по записи e2e4 / e7e8q; -1 если нет. */
    public int find(String u) {
        for (int m : legal()) if (uci(m).equals(u)) return m;
        return -1;
    }

    public long perft(int d) {
        if (d == 0) return 1;
        int[] m = legal();
        if (d == 1) return m.length;
        long n = 0;
        for (int x : m) { Position q = copy(); q.make(x); n += q.perft(d - 1); }
        return n;
    }
}
