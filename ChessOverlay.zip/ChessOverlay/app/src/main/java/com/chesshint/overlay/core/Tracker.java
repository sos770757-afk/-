package com.chesshint.overlay.core;

import java.util.Arrays;

/** Следит за партией: превращает расстановки, увиденные на экране, в позиции с очередью хода, рокировками и «на проходе». */
public final class Tracker {
    public enum Status { SAME, UPDATED, RESET, INVALID }

    public Position cur;                 // null — позиция неизвестна
    public volatile boolean whiteBottom = true;
    private boolean stmKnown;               // очередь хода известна точно (не угадана по расстановке)
    private static final byte[] START = Position.start().b;

    public static boolean valid(byte[] o) {
        int wk = 0, bk = 0, wp = 0, bp = 0, wn = 0, bn = 0;
        for (int i = 0; i < 64; i++) {
            int pc = o[i];
            if (pc == 0) continue;
            boolean w = (pc & 8) == 0;
            int t = pc & 7;
            if (t == Position.K) { if (w) wk++; else bk++; }
            if (t == Position.P) { if (i < 8 || i >= 56) return false; if (w) wp++; else bp++; }
            if (w) wn++; else bn++;
        }
        if (wk != 1 || bk != 1 || wp > 8 || bp > 8 || wn > 16 || bn > 16) return false;
        int k1 = -1, k2 = -1;
        for (int i = 0; i < 64; i++) { if (o[i] == Position.K) k1 = i; if (o[i] == (8 | Position.K)) k2 = i; }
        return Math.abs((k1 & 7) - (k2 & 7)) > 1 || Math.abs((k1 >> 3) - (k2 >> 3)) > 1;
    }

    private static int diff(byte[] a, byte[] b) {
        int d = 0;
        for (int i = 0; i < 64; i++) if (a[i] != b[i]) d++;
        return d;
    }

    private static Position search(Position p, byte[] obs, int depth) {
        for (int m : p.legal()) {
            Position q = p.copy();
            q.make(m);
            int d = diff(q.b, obs);
            if (d == 0) return q;
            if (depth > 1 && d <= 4 * (depth - 1)) {
                Position r = search(q, obs, depth - 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    /** Кратчайшая цепочка ходов (до 4 полуходов), дающая расстановку obs. tryFlip — проверять и «чужую» очередь хода. */
    private static Position follow(Position p, byte[] obs, boolean tryFlip) {
        Position fl = null;
        if (tryFlip) { fl = p.copy(); fl.white = !fl.white; fl.ep = -1; }
        for (int d = 1; d <= 4; d++) {
            Position r = search(p, obs, d);
            if (r != null) return r;
            if (fl != null) { r = search(fl, obs, d); if (r != null) return r; }
        }
        return null;
    }

    private static byte[] rotate(byte[] o) {
        byte[] r = new byte[64];
        for (int i = 0; i < 64; i++) r[i] = o[63 - i];
        return r;
    }

    /** obs — расстановка в координатах доски (a1=0) при текущем whiteBottom. */
    public Status update(byte[] obs) {
        if (!valid(obs)) return Status.INVALID;
        if (cur != null) {
            if (cur.samePlacement(obs)) return Status.SAME;
            Position nx = follow(cur, obs, !stmKnown);
            if (nx != null) { cur = nx; stmKnown = true; return Status.UPDATED; }
            // возможно, пользователь перевернул доску в приложении
            byte[] rot = rotate(obs);
            if (cur.samePlacement(rot)) { whiteBottom = !whiteBottom; return Status.SAME; }
            nx = follow(cur, rot, !stmKnown);
            if (nx != null) { whiteBottom = !whiteBottom; cur = nx; stmKnown = true; return Status.UPDATED; }
        }
        if (Arrays.equals(obs, START)) { cur = Position.start(); stmKnown = true; return Status.RESET; }
        cur = guess(obs);
        stmKnown = false;
        return Status.RESET;
    }

    private Position guess(byte[] obs) {
        Position q = Position.fromPlacement(obs, whiteBottom);   // ходит тот, кто внизу (игрок)
        int ok = q.kingSq(!q.white);
        if (ok >= 0 && q.attacked(ok, q.white)) q.white = !q.white;   // король соперника под боем — так быть не может
        return q;
    }

    public boolean userToMove() { return cur != null && cur.white == whiteBottom; }
}
