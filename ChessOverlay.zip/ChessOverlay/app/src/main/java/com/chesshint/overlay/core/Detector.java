package com.chesshint.overlay.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

/**
 * Поиск шахматной доски на снимке экрана и распознавание фигур.
 * Работает с массивом ARGB-пикселей. Набор фигур приложения запоминается автоматически по стартовой позиции.
 */
public final class Detector {
    private Detector() {}

    static final int N = 64, G = 32;
    static final int T_FG = 60, T_FG2 = 110;
    static final float MAX_D = 0.25f, MIN_MARGIN = 0.04f;
    public static volatile float dbgWorstD, dbgMinMargin;

    public static final class Geo {
        public float x, y, cell;
        public int light, dark;
    }

    public static final class Cell {
        public boolean occ;
        public float[] cov;
        public float tone;
    }

    public static final class Scan {
        public byte[] board;        // расстановка в координатах доски (a1=0) или null
        public boolean learned;     // набор фигур выучен по стартовой позиции на этом кадре
        public boolean whiteBottom;
        public String problem;      // null | need_start | unknown
    }

    public static final class PieceSet {
        public final float[][] tmpl = new float[7][];
        public float toneW = 200, toneB = 60;
        public boolean ready;
        private static final int MAGIC = 0x43485331;

        float thresh() { return (toneW + toneB) / 2f; }

        public void save(File f) throws IOException {
            try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)))) {
                o.writeInt(MAGIC); o.writeFloat(toneW); o.writeFloat(toneB);
                for (int t = 1; t <= 6; t++) for (int k = 0; k < G * G; k++) o.writeFloat(tmpl[t][k]);
            }
        }

        public static PieceSet load(File f) {
            PieceSet s = new PieceSet();
            try (DataInputStream i = new DataInputStream(new BufferedInputStream(new FileInputStream(f)))) {
                if (i.readInt() != MAGIC) return s;
                s.toneW = i.readFloat(); s.toneB = i.readFloat();
                for (int t = 1; t <= 6; t++) { s.tmpl[t] = new float[G * G]; for (int k = 0; k < G * G; k++) s.tmpl[t][k] = i.readFloat(); }
                s.ready = true;
            } catch (IOException e) { s.ready = false; }
            return s;
        }
    }

    // ---------------------------------------------------------------- вспомогательное
    public static int lum(int c) { return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 150 + (c & 255) * 29) >> 8; }

    static int cdiff(int a, int b) {
        return Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)) + Math.abs((a & 255) - (b & 255));
    }

    private static int box(int[] I, int iw, int x, int y, int bw, int bh) {
        return I[(y + bh) * iw + x + bw] - I[y * iw + x + bw] - I[(y + bh) * iw + x] + I[y * iw + x];
    }

    // ---------------------------------------------------------------- поиск доски
    private static final int[] ORDER = new int[64];
    static { for (int k = 0; k < 64; k++) ORDER[k] = (k * 29) & 63; }

    private static float evalGrid(int[] I, int iw, int x0, int y0, float s, float[] v) {
        int cs = Math.round(s), p = Math.max(1, Math.round(s * 0.14f)), a = Math.max(1, Math.round(s * 0.08f));
        float sl = 0, sd = 0;
        int nl = 0, nd = 0;
        for (int k = 0; k < 64; k++) {
            int idx = ORDER[k], i = idx >> 3, j = idx & 7;
            int cx = x0 + Math.round(j * s), cy = y0 + Math.round(i * s);
            float val = (box(I, iw, cx + a, cy + a, p, p) + box(I, iw, cx + cs - a - p, cy + cs - a - p, p, p)) / (2f * p * p);
            v[idx] = val;
            if (((i + j) & 1) == 0) { sl += val; nl++; } else { sd += val; nd++; }
            if (k == 11) {
                if (nl < 3 || nd < 3) return 0;
                float ml = sl / nl, md = sd / nd;
                if (ml - md < 12) return 0;
                float tol = Math.max(8f, 0.4f * (ml - md));
                int bad = 0;
                for (int q = 0; q <= 11; q++) {
                    int id2 = ORDER[q];
                    float m = (((id2 >> 3) + (id2 & 7)) & 1) == 0 ? ml : md;
                    if (Math.abs(v[id2] - m) > tol) bad++;
                }
                if (bad > 1) return 0;
            }
        }
        float ml = sl / nl, md = sd / nd, con = ml - md;
        if (con < 12) return 0;
        float tol = Math.max(8f, 0.4f * con);
        int good = 0;
        for (int idx = 0; idx < 64; idx++) {
            float m = (((idx >> 3) + (idx & 7)) & 1) == 0 ? ml : md;
            if (Math.abs(v[idx] - m) <= tol) good++;
        }
        return good < 55 ? 0 : good * con;
    }

    private static float[] comb(float[] e, float p0, float c0, int pad, float cpad) {
        float bestV = -1, bp = p0, bc = c0;
        int n = e.length;
        for (float p = p0 - pad; p <= p0 + pad; p += 0.5f)
            for (float c = c0 - cpad; c <= c0 + cpad; c += 0.05f) {
                float sum = 0;
                boolean ok = true;
                for (int j = 0; j <= 8; j++) {
                    int i = Math.round(p + j * c);
                    if (i < 1 || i >= n - 1) { ok = false; break; }
                    sum += e[i - 1] + e[i] + e[i + 1];
                }
                if (ok && sum > bestV) { bestV = sum; bp = p; bc = c; }
            }
        return new float[]{bp, bc};
    }

    /** Ищет доску (сетка 8x8 из двух чередующихся цветов, светлая клетка слева сверху). null — не найдено. */
    public static Geo find(int[] px, int w, int h) {
        int f = Math.max(1, Math.round(Math.min(w, h) / 270f));
        int dw = w / f, dh = h / f, iw = dw + 1;
        int[] I = new int[iw * (dh + 1)];
        for (int y = 0; y < dh; y++) {
            int rowSum = 0;
            for (int x = 0; x < dw; x++) {
                int sum = 0;
                for (int yy = 0; yy < f; yy++) {
                    int base = (y * f + yy) * w + x * f;
                    for (int xx = 0; xx < f; xx++) sum += lum(px[base + xx]);
                }
                rowSum += sum / (f * f);
                I[(y + 1) * iw + x + 1] = I[y * iw + x + 1] + rowSum;
            }
        }
        int m = Math.min(dw, dh);
        float sMax = m / 8f, sMin = Math.max(5f, m * 0.3f / 8f);
        float best = 0, bs = 0;
        int bx = 0, by = 0;
        float[] v = new float[64];
        for (float s = sMax; s >= sMin; s -= 0.5f) {
            int bw = Math.round(8 * s);
            for (int y0 = 0; y0 + bw <= dh; y0 += 2)
                for (int x0 = 0; x0 + bw <= dw; x0 += 2) {
                    float sc = evalGrid(I, iw, x0, y0, s, v);
                    if (sc > best) { best = sc; bx = x0; by = y0; bs = s; }
                }
        }
        if (best <= 0) return null;

        // уточнение на полном разрешении по линиям сетки
        float C0 = bs * f, S8 = 8 * C0;
        int X0 = bx * f, Y0 = by * f, pad = f + 4;
        Geo g0 = new Geo();
        g0.x = X0; g0.y = Y0; g0.cell = C0;
        int te = check(g0, px, w, h) ? cdiff(g0.light, g0.dark) / 2 : 60;
        float[] colE = new float[w + 3], rowE = new float[h + 3];
        int ya = Math.max(1, Math.round(Y0 + 0.06f * S8)), yb = Math.min(h - 1, Math.round(Y0 + 0.94f * S8));
        int xa = Math.max(1, X0 - pad - 2), xb = Math.min(w - 1, Math.round(X0 + S8) + pad + 2);
        for (int y = ya; y < yb; y += 2) { int row = y * w; for (int x = xa; x <= xb; x++) if (cdiff(px[row + x], px[row + x - 1]) > te) colE[x] += 1; }
        int xa2 = Math.max(0, Math.round(X0 + 0.06f * S8)), xb2 = Math.min(w, Math.round(X0 + 0.94f * S8));
        int ya2 = Math.max(1, Y0 - pad - 2), yb2 = Math.min(h - 1, Math.round(Y0 + S8) + pad + 2);
        for (int y = ya2; y <= yb2; y++) { int row = y * w; for (int x = xa2; x < xb2; x += 2) if (cdiff(px[row + x], px[row - w + x]) > te) rowE[y] += 1; }
        float cpad = f * 0.5f + 1f;
        float[] rx = comb(colE, X0, C0, pad, cpad), ry = comb(rowE, Y0, C0, pad, cpad);
        Geo g = new Geo();
        g.x = rx[0]; g.y = ry[0]; g.cell = (rx[1] + ry[1]) / 2f;
        if (check(g, px, w, h)) return g;
        return check(g0, px, w, h) ? g0 : null;
    }

    private static int cellBg(int[] px, int w, int h, int x0, int y0, int cw, int ch) {
        int pw = Math.max(2, Math.round(cw * 0.14f)), a = Math.max(1, Math.round(cw * 0.05f));
        int[] ox = {a, Math.max(0, cw - a - pw), a, Math.max(0, cw - a - pw)};
        int[] oy = {a, a, Math.max(0, ch - a - pw), Math.max(0, ch - a - pw)};
        int[][] m = new int[3][4];
        for (int k = 0; k < 4; k++) {
            long r = 0, g = 0, b = 0;
            int n = 0;
            for (int yy = 0; yy < pw; yy++) for (int xx = 0; xx < pw; xx++) {
                int X = x0 + ox[k] + xx, Y = y0 + oy[k] + yy;
                if (X < 0 || Y < 0 || X >= w || Y >= h) continue;
                int c = px[Y * w + X];
                r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255; n++;
            }
            if (n == 0) n = 1;
            m[0][k] = (int) (r / n); m[1][k] = (int) (g / n); m[2][k] = (int) (b / n);
        }
        int[] o = new int[3];
        for (int c = 0; c < 3; c++) { Arrays.sort(m[c]); o[c] = (m[c][1] + m[c][2]) / 2; }
        return (o[0] << 16) | (o[1] << 8) | o[2];
    }

    /** Проверяет, что на месте geo всё ещё чередуются светлые и тёмные клетки; заполняет light/dark. */
    public static boolean check(Geo g, int[] px, int w, int h) {
        if (!(g.cell > 6) || g.x < -1 || g.y < -1 || g.x + 8 * g.cell > w + 1 || g.y + 8 * g.cell > h + 1) return false;
        float[] lm = new float[64];
        int[] col = new int[64];
        float sl = 0, sd = 0;
        int nl = 0, nd = 0;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int x0 = Math.round(g.x + j * g.cell), y0 = Math.round(g.y + i * g.cell);
            int x1 = Math.round(g.x + (j + 1) * g.cell), y1 = Math.round(g.y + (i + 1) * g.cell);
            int c = cellBg(px, w, h, x0, y0, x1 - x0, y1 - y0);
            col[i * 8 + j] = c; lm[i * 8 + j] = lum(c);
            if (((i + j) & 1) == 0) { sl += lm[i * 8 + j]; nl++; } else { sd += lm[i * 8 + j]; nd++; }
        }
        float ml = sl / nl, md = sd / nd, con = ml - md;
        if (con < 12) return false;
        float tol = Math.max(10f, 0.4f * con);
        int good = 0;
        long[] L = new long[3], D = new long[3];
        int gl = 0, gd = 0;
        for (int idx = 0; idx < 64; idx++) {
            boolean light = (((idx >> 3) + (idx & 7)) & 1) == 0;
            if (Math.abs(lm[idx] - (light ? ml : md)) > tol) continue;
            good++;
            long[] t = light ? L : D;
            t[0] += (col[idx] >> 16) & 255; t[1] += (col[idx] >> 8) & 255; t[2] += col[idx] & 255;
            if (light) gl++; else gd++;
        }
        if (good < 55 || gl == 0 || gd == 0) return false;
        g.light = ((int) (L[0] / gl) << 16) | ((int) (L[1] / gl) << 8) | (int) (L[2] / gl);
        g.dark = ((int) (D[0] / gd) << 16) | ((int) (D[1] / gd) << 8) | (int) (D[2] / gd);
        return true;
    }

    // ---------------------------------------------------------------- анализ клетки
    public static Cell[] cells(Geo g, int[] px, int w, int h, int thr) {
        Cell[] out = new Cell[64];
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int x0 = Math.round(g.x + j * g.cell), x1 = Math.round(g.x + (j + 1) * g.cell);
            int y0 = Math.round(g.y + i * g.cell), y1 = Math.round(g.y + (i + 1) * g.cell);
            out[i * 8 + j] = analyze(px, w, h, x0, y0, x1 - x0, y1 - y0, thr);
        }
        return out;
    }

    /** Можно ли «протечь» фоном из бина k в соседний k2. В режиме градиента — пока цвет меняется плавно. */
    private static boolean flow(boolean grad, boolean[] fg, int[] ar, int[] ag, int[] ab, int k, int k2) {
        if (!grad) return !fg[k2];
        return Math.abs(ar[k] - ar[k2]) + Math.abs(ag[k] - ag[k2]) + Math.abs(ab[k] - ab[k2]) < 30;
    }

    private static Cell analyze(int[] px, int w, int h, int x0, int y0, int cw, int ch, int thr) {
        Cell cell = new Cell();
        cell.cov = new float[G * G];
        if (cw < 8 || ch < 8) return cell;
        int bg = cellBg(px, w, h, x0, y0, cw, ch);
        int br = (bg >> 16) & 255, bgn = (bg >> 8) & 255, bb = bg & 255;
        int[] sr = new int[N * N], sg = new int[N * N], sb = new int[N * N], cnt = new int[N * N];
        for (int yy = 0; yy < ch; yy++) {
            int Y = y0 + yy;
            if (Y < 0 || Y >= h) continue;
            int by = yy * N / ch;
            for (int xx = 0; xx < cw; xx++) {
                int X = x0 + xx;
                if (X < 0 || X >= w) continue;
                int c = px[Y * w + X], k = by * N + xx * N / cw;
                sr[k] += (c >> 16) & 255; sg[k] += (c >> 8) & 255; sb[k] += c & 255; cnt[k]++;
            }
        }
        boolean grad = thr <= 0;
        boolean[] fg = new boolean[N * N];
        float[] bl = new float[N * N];
        int[] ar = new int[N * N], ag = new int[N * N], ab = new int[N * N];
        for (int k = 0; k < N * N; k++) {
            if (cnt[k] == 0) continue;
            ar[k] = sr[k] / cnt[k]; ag[k] = sg[k] / cnt[k]; ab[k] = sb[k] / cnt[k];
            bl[k] = (ar[k] * 77 + ag[k] * 150 + ab[k] * 29) >> 8;
        }
        if (!grad) for (int y = 2; y < N - 2; y++) for (int x = 2; x < N - 2; x++) {
            int k = y * N + x;
            if (cnt[k] == 0) continue;
            if (Math.abs(ar[k] - br) + Math.abs(ag[k] - bgn) + Math.abs(ab[k] - bb) > thr) fg[k] = true;
        }
        // фон, достижимый от края; всё остальное (включая «дырки» внутри контура) — силуэт
        boolean[] reach = new boolean[N * N];
        int[] st = new int[N * N * 2];
        int sp = 0;
        for (int i = 0; i < N; i++) {
            int[] seeds = {i, (N - 1) * N + i, i * N, i * N + N - 1};
            for (int s : seeds) if (!fg[s] && !reach[s]) { reach[s] = true; st[sp++] = s; }
        }
        while (sp > 0) {
            int k = st[--sp], x = k % N, y = k / N;
            if (x > 0 && !reach[k - 1] && flow(grad, fg, ar, ag, ab, k, k - 1)) { reach[k - 1] = true; st[sp++] = k - 1; }
            if (x < N - 1 && !reach[k + 1] && flow(grad, fg, ar, ag, ab, k, k + 1)) { reach[k + 1] = true; st[sp++] = k + 1; }
            if (y > 0 && !reach[k - N] && flow(grad, fg, ar, ag, ab, k, k - N)) { reach[k - N] = true; st[sp++] = k - N; }
            if (y < N - 1 && !reach[k + N] && flow(grad, fg, ar, ag, ab, k, k + N)) { reach[k + N] = true; st[sp++] = k + N; }
        }
        boolean[] sil = new boolean[N * N];
        for (int k = 0; k < N * N; k++) sil[k] = !reach[k];
        // самая большая связная область (отбрасываем подписи, точки-подсказки и т.п.)
        int[] lab = new int[N * N];
        int bestLab = 0, bestSize = 0, nl = 0;
        for (int s0 = 0; s0 < N * N; s0++) {
            if (!sil[s0] || lab[s0] != 0) continue;
            nl++;
            int size = 0;
            sp = 0; st[sp++] = s0; lab[s0] = nl;
            while (sp > 0) {
                int k = st[--sp], x = k % N, y = k / N;
                size++;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue;
                    int k2 = yy * N + xx;
                    if (sil[k2] && lab[k2] == 0) { lab[k2] = nl; st[sp++] = k2; }
                }
            }
            if (size > bestSize) { bestSize = size; bestLab = nl; }
        }
        int minx = N, maxx = -1, miny = N, maxy = -1;
        for (int k = 0; k < N * N; k++) {
            sil[k] = lab[k] == bestLab && bestLab != 0;
            if (sil[k]) { int x = k % N, y = k / N; minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); }
        }
        float frac = bestSize / (float) (N * N);
        cell.occ = bestSize > 0 && frac >= 0.10f && (maxy - miny + 1) >= 0.34f * N && (maxx - minx + 1) >= 0.2f * N;
        if (!cell.occ) return cell;
        boolean[] in = sil.clone();
        for (int it = 0; it < 2; it++) {
            boolean[] nx = new boolean[N * N];
            for (int y = 1; y < N - 1; y++) for (int x = 1; x < N - 1; x++) {
                int k = y * N + x;
                nx[k] = in[k] && in[k - 1] && in[k + 1] && in[k - N] && in[k + N];
            }
            in = nx;
        }
        float ts = 0, ta = 0;
        int tn = 0, tna = 0;
        for (int k = 0; k < N * N; k++) { if (in[k]) { ts += bl[k]; tn++; } if (sil[k]) { ta += bl[k]; tna++; } }
        cell.tone = tn >= 8 ? ts / tn : ta / Math.max(1, tna);
        for (int gy = 0; gy < G; gy++) for (int gx = 0; gx < G; gx++) {
            int c = 0;
            for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) if (sil[(2 * gy + dy) * N + 2 * gx + dx]) c++;
            cell.cov[gy * G + gx] = c / 4f;
        }
        return cell;
    }

    static float dist(float[] a, float[] b) {
        float s = 0, t = 0;
        for (int k = 0; k < a.length; k++) { s += Math.abs(a[k] - b[k]); t += a[k] + b[k]; }
        return t < 1e-3f ? 1f : 2f * s / t;
    }

    // ---------------------------------------------------------------- стартовая позиция и обучение
    private static final int[] BACK = {Position.R, Position.N, Position.B, Position.Q, Position.K, Position.B, Position.N, Position.R};

    /** Если кадр похож на стартовую позицию — возвращает true, когда белые внизу; иначе null. */
    public static Boolean startLike(Cell[] c) {
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            boolean should = i <= 1 || i >= 6;
            if (c[i * 8 + j].occ != should) return null;
        }
        float top = 0, bot = 0;
        for (int j = 0; j < 8; j++) for (int i = 0; i < 2; i++) { top += c[i * 8 + j].tone; bot += c[(i + 6) * 8 + j].tone; }
        top /= 16; bot /= 16;
        if (Math.abs(top - bot) < 40) return null;
        float mid = (top + bot) / 2;
        for (int j = 0; j < 8; j++) for (int i = 0; i < 2; i++) {
            boolean topOk = top > bot ? c[i * 8 + j].tone > mid : c[i * 8 + j].tone < mid;
            boolean botOk = top > bot ? c[(i + 6) * 8 + j].tone < mid : c[(i + 6) * 8 + j].tone > mid;
            if (!topOk || !botOk) return null;
        }
        return bot > top;
    }

    /** Запоминает вид фигур по стартовой позиции. */
    public static boolean train(Cell[] c, PieceSet set, boolean whiteBottom) {
        float[][] acc = new float[7][G * G];
        int[] cnt = new int[7];
        float tw = 0, tb = 0;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            if (!(i <= 1 || i >= 6)) continue;
            boolean bottomSide = i >= 6;
            boolean whiteSide = bottomSide == whiteBottom;
            int own = bottomSide ? 7 - i : i;
            int type = own == 1 ? Position.P : BACK[whiteBottom ? j : 7 - j];
            for (int k = 0; k < G * G; k++) acc[type][k] += c[i * 8 + j].cov[k];
            cnt[type]++;
            if (whiteSide) tw += c[i * 8 + j].tone; else tb += c[i * 8 + j].tone;
        }
        for (int t = 1; t <= 6; t++) { if (cnt[t] == 0) return false; for (int k = 0; k < G * G; k++) acc[t][k] /= cnt[t]; }
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {   // все пешки должны быть похожи друг на друга
            if (i == 1 || i == 6) if (dist(c[i * 8 + j].cov, acc[Position.P]) > 0.5f) return false;
        }
        for (int t = 1; t <= 6; t++) set.tmpl[t] = acc[t];
        set.toneW = tw / 16; set.toneB = tb / 16;
        set.ready = true;
        return true;
    }

    /** Фигура по клетке: тип 1..6 (+8 для чёрных) или 0, если клетка пуста / фигура не опознана. */
    private static int matchCell(Cell ce, PieceSet set) {
        if (!ce.occ) return 0;
        int best = 0;
        float bd = 9, sd = 9;
        for (int t = 1; t <= 6; t++) {
            float d = dist(ce.cov, set.tmpl[t]);
            if (d < bd) { sd = bd; bd = d; best = t; } else if (d < sd) sd = d;
        }
        if (bd > MAX_D || sd - bd < MIN_MARGIN) return 0;
        dbgWorstD = Math.max(dbgWorstD, bd); dbgMinMargin = Math.min(dbgMinMargin, sd - bd);
        return ce.tone >= set.thresh() ? best : (best | 8);
    }

    private static int sqOf(int i, int j, boolean whiteBottom) { return whiteBottom ? (7 - i) * 8 + j : i * 8 + (7 - j); }

    /** Классификация без запасных режимов (для проверки обучения). */
    public static byte[] classify(Cell[] c, PieceSet set, boolean whiteBottom) {
        byte[] out = new byte[64];
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            if (!c[i * 8 + j].occ) continue;
            int pc = matchCell(c[i * 8 + j], set);
            if (pc == 0) return null;
            out[sqOf(i, j, whiteBottom)] = (byte) pc;
        }
        return out;
    }

    /** Для неопознанных клеток пробует другие пороги маски и режим градиента (шах, подсветки). */
    private static byte[] classifyAll(Geo g, int[] px, int w, int h, Cell[] c, PieceSet set, boolean whiteBottom) {
        byte[] out = new byte[64];
        Cell[] c2 = null, c3 = null;
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) {
            int idx = i * 8 + j;
            if (!c[idx].occ) continue;
            int pc = matchCell(c[idx], set);
            if (pc == 0) { if (c2 == null) c2 = cells(g, px, w, h, T_FG2); pc = matchCell(c2[idx], set); }
            if (pc == 0) { if (c3 == null) c3 = cells(g, px, w, h, 0); pc = matchCell(c3[idx], set); }
            if (pc == 0) return null;
            out[sqOf(i, j, whiteBottom)] = (byte) pc;
        }
        return out;
    }

    /** Полный разбор кадра. На стартовой позиции набор фигур всегда переобучается по самому кадру. */
    public static Scan scan(int[] px, int w, int h, Geo g, PieceSet set, boolean whiteBottom) {
        Scan r = new Scan();
        r.whiteBottom = whiteBottom;
        dbgWorstD = 0; dbgMinMargin = 9;
        Cell[] c = cells(g, px, w, h, T_FG);
        Boolean so = startLike(c);
        if (so != null && train(c, set, so)) {
            r.learned = true; r.whiteBottom = so;
            r.board = classify(c, set, so);
            if (r.board == null) r.problem = "unknown";
            return r;
        }
        if (set.ready) {
            byte[] b = classifyAll(g, px, w, h, c, set, whiteBottom);
            if (b != null) { r.board = b; return r; }
        }
        r.problem = set.ready ? "unknown" : "need_start";
        return r;
    }
}
