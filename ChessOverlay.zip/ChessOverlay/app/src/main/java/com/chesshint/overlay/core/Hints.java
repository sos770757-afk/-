package com.chesshint.overlay.core;

import java.util.ArrayList;
import java.util.List;

/** Выбор подсказки по уровню, текст оценки и поиск угроз. */
public final class Hints {
    private Hints() {}

    /** level: 0 — лучшие, 1 — средние, 2 — слабые/ошибки. Линии отсортированы по убыванию. */
    public static Engine.Line pick(List<Engine.Line> lines, int level) {
        if (lines.isEmpty()) return null;
        Engine.Line best = lines.get(0);
        if (level == 0 || lines.size() == 1) return best;
        int top = Engine.score(best);
        if (level == 1) {
            for (int i = 1; i < lines.size(); i++) {
                int loss = top - Engine.score(lines.get(i));
                if (loss >= 25 && loss <= 120) return lines.get(i);
            }
            return lines.get(1);
        }
        Engine.Line pick = lines.get(1);
        for (int i = 1; i < lines.size(); i++) if (top - Engine.score(lines.get(i)) <= 400) pick = lines.get(i);
        return pick;
    }

    /** Оценка в пешках с точки зрения белых, обрезанная до ±10. */
    public static float pawnsWhite(Engine.Line l, boolean whiteToMove) {
        float v = l.mate != 0 ? (l.mate > 0 ? 10f : -10f) : Math.max(-1000, Math.min(1000, l.cp)) / 100f;
        return whiteToMove ? v : -v;
    }

    public static String evalText(Engine.Line l, boolean whiteToMove) {
        if (l.mate != 0) {
            boolean whiteMates = (l.mate > 0) == whiteToMove;
            return (whiteMates ? "M" : "-M") + Math.abs(l.mate);
        }
        float v = pawnsWhite(l, whiteToMove);
        return (v > 0 ? "+" : "") + String.format(java.util.Locale.US, "%.2f", v);
    }

    public static final class Threats {
        public final List<int[]> arrows = new ArrayList<>();   // {from, to}
        public final List<Integer> squares = new ArrayList<>();
        public boolean mate;
    }

    private static boolean attacks(Position p, int from, int to) {
        int pc = p.b[from], t = pc & 7, fr = from >> 3, ff = from & 7, tr = to >> 3, tf = to & 7;
        int dr = tr - fr, df = tf - ff;
        if (dr == 0 && df == 0) return false;
        switch (t) {
            case Position.P: return Math.abs(df) == 1 && dr == ((pc & 8) == 0 ? 1 : -1);
            case Position.N: return (Math.abs(dr) == 2 && Math.abs(df) == 1) || (Math.abs(dr) == 1 && Math.abs(df) == 2);
            case Position.K: return Math.abs(dr) <= 1 && Math.abs(df) <= 1;
            default: break;
        }
        boolean diag = Math.abs(dr) == Math.abs(df), line = dr == 0 || df == 0;
        if (t == Position.B && !diag) return false;
        if (t == Position.R && !line) return false;
        if (t == Position.Q && !diag && !line) return false;
        int sr = Integer.signum(dr), sf = Integer.signum(df);
        for (int r = fr + sr, f = ff + sf; r != tr || f != tf; r += sr, f += sf) if (p.b[r * 8 + f] != 0) return false;
        return true;
    }

    /** Фигуры стороны «white», которым грозит потеря: под боем и не защищены либо бьёт более дешёвая. */
    public static List<Integer> endangered(Position p, boolean white) {
        List<Integer> res = new ArrayList<>();
        for (int sq = 0; sq < 64; sq++) {
            int pc = p.b[sq];
            if (pc == 0 || ((pc & 8) == 0) != white) continue;
            int t = pc & 7;
            if (t == Position.K) { if (p.attacked(sq, !white)) res.add(sq); continue; }
            int minAtt = 100000, def = 0;
            for (int s2 = 0; s2 < 64; s2++) {
                int q = p.b[s2];
                if (q == 0 || s2 == sq) continue;
                boolean qw = (q & 8) == 0;
                if (!attacks(p, s2, sq)) continue;
                if (qw == white) def++; else minAtt = Math.min(minAtt, Engine.VAL[q & 7] == 0 ? 20000 : Engine.VAL[q & 7]);
            }
            if (minAtt < 100000 && (def == 0 || minAtt < Engine.VAL[t])) res.add(sq);
        }
        return res;
    }

    /** Что грозит стороне, чей ход: «пас» и лучший ответ соперника. myBest — наша лучшая линия. */
    public static Threats threats(Position pos, Engine.Analyzer an, Engine.Line myBest, int ms) {
        Threats th = new Threats();
        th.squares.addAll(endangered(pos, pos.white));
        if (pos.inCheck() || myBest == null) return th;
        try {
            Position nm = pos.copy();
            nm.white = !nm.white;
            nm.ep = -1;
            List<Engine.Line> ls = an.analyze(nm, 2, ms);
            if (ls.isEmpty()) return th;
            Engine.Line o = ls.get(0);
            int gain = Engine.score(o) + Engine.score(myBest);
            boolean mt = o.mate > 0;
            if (mt || gain >= 120) {
                th.mate = mt;
                addArrow(th, o.move);
                if (ls.size() > 1 && !mt && Engine.score(o) - Engine.score(ls.get(1)) <= 40) addArrow(th, ls.get(1).move);
            }
        } catch (Exception ignored) { }
        return th;
    }

    private static void addArrow(Threats th, String u) {
        if (u == null || u.length() < 4) return;
        th.arrows.add(new int[]{Position.sqOf(u.substring(0, 2)), Position.sqOf(u.substring(2, 4))});
    }
}
